package com.sara.cta07_unitconverterapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class ConverterUnitTest {

    @Test
    public void testKmToM() {
        assertEquals(1000.0, ConverterUnit.kmToM(1.0), 0.0);
    }

    @Test
    public void testKmToCm() {
        assertEquals(100000.0, ConverterUnit.kmToCm(1.0), 0.0);
    }

    @Test
    public void testKmToMile() {
        assertEquals(1.0, ConverterUnit.kmToMile(1.609), 0.0);
    }

    @Test
    public void testKmToYard() {
        assertEquals(1094.0, ConverterUnit.kmToYard(1.0), 0.0);
    }

    @Test
    public void testKmToFoot() {
        assertEquals(3281.0, ConverterUnit.kmToFoot(1.0), 0.0);
    }

    @Test
    public void testKmToInch() {
        assertEquals(39370.0, ConverterUnit.kmToInch(1.0), 0.0);
    }
}
