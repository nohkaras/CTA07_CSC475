package com.sara.cta07_unitconverterapp;

public class ConverterUnit {
    public static double kmToM(double km) {
        return km * 1000;
    }

    public static double kmToCm(double km) {
        return km * 100000;
    }

    public static double kmToMile(double km) {
        return km / 1.609;
    }

    public static double kmToYard(double km) {
        return km * 1094;
    }

    public static double kmToFoot(double km) {
        return km * 3281;
    }

    public static double kmToInch(double km) {
        return km * 39370;
    }
}

